# Bangla Trend Hub

এই project একটি mobile-friendly বাংলা blog/CMS starter।

## চালানোর নিয়ম
1. ZIP extract করুন।
2. `index.html` খুলে design দেখুন।
3. Hosting-এ পুরো folder upload করুন।
4. Admin demo: `/admin/login.html`
5. Demo credentials: `admin` / `admin123`

## গুরুত্বপূর্ণ
এই Admin system শুধুমাত্র frontend/localStorage demo। Production website-এর জন্য:
- server-side authentication
- hashed password
- database
- backend API
- CSRF/XSS protection
- server-side validation
প্রয়োজন।

## Adsterra
Homepage/article-এর `ad-box` placeholder-এ Adsterra থেকে পাওয়া নির্দিষ্ট ad code বসান। নিজে ad click বা fake traffic তৈরি করবেন না।

## Contact
বর্তমান contact form demo। বাস্তবে backend বা trusted form/email service সংযুক্ত করতে হবে।
